MOVIX PRIME — Android starter project

This is a starter Android Studio project, not a compiled APK.
Included in version 1:
- MOVIX PRIME dark/neon themed home screen
- Android system video picker
- Video preview with playback controls

Not implemented yet:
- Actual timeline trimming/rendering
- Music mixing, filters, transitions, 4K export

Build requirements:
- Android Studio with Android SDK 35
- JDK 17
Open this folder in Android Studio and build the app. The generated APK can then be installed on your Android phone.

This is an original starter implementation and does not contain Apple's iMovie code or assets.
