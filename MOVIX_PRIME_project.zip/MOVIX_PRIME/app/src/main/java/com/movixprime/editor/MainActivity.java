package com.movixprime.editor;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 41;
    private LinearLayout root;
    private VideoView videoView;
    private TextView status;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,9,20));
        getWindow().setNavigationBarColor(Color.rgb(8,9,20));
        buildScreen();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void buildScreen() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(18)); root.setBackgroundColor(Color.rgb(8,9,20));
        setContentView(root);

        TextView brand = text("✦  MOVIX PRIME", 27, Color.WHITE, true);
        brand.setGravity(Gravity.CENTER); root.addView(brand, new LinearLayout.LayoutParams(-1, dp(58)));
        TextView tagline = text("YOUR STORY. YOUR CINEMA.", 11, Color.rgb(151,154,190), true);
        tagline.setGravity(Gravity.CENTER); root.addView(tagline);

        TextView heading = text("My Projects", 23, Color.WHITE, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2); hp.topMargin = dp(34); hp.bottomMargin = dp(14); root.addView(heading, hp);

        Button create = new Button(this); create.setText("＋   New Movie"); create.setTextSize(16);
        create.setTextColor(Color.WHITE); create.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(93,76,210)));
        root.addView(create, new LinearLayout.LayoutParams(-1, dp(54)));
        create.setOnClickListener(v -> chooseVideo());

        videoView = new VideoView(this); videoView.setBackgroundColor(Color.rgb(18,20,38));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(220)); vp.topMargin = dp(22); root.addView(videoView, vp);
        status = text("Choose a video to start your first project.", 14, Color.rgb(177,181,210), false);
        status.setGravity(Gravity.CENTER); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(12); root.addView(status, sp);

        TextView tools = text("EDITING TOOLS", 12, Color.rgb(139,121,255), true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2); tp.topMargin = dp(28); tp.bottomMargin = dp(10); root.addView(tools, tp);
        String[] labels = {"✂  Trim video     •     🎵  Add music", "✦  Filters          •     ⇄  Transitions", "◉  Preview        •     ⤓  Export"};
        for (String s : labels) { TextView row = text(s, 14, Color.rgb(220,222,242), false); row.setPadding(dp(14), dp(13), dp(14), dp(13)); row.setBackgroundColor(Color.rgb(19,21,40)); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(7); root.addView(row,p); }
        TextView note = text("MOVIX PRIME • Version 1.0 preview", 11, Color.rgb(112,116,151), false);
        note.setGravity(Gravity.CENTER); LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2); np.topMargin = dp(18); root.addView(note,np);
    }
    private void chooseVideo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("video/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_VIDEO);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                videoView.setVideoURI(uri);
                videoView.setMediaController(new MediaController(this));
                videoView.start();
                status.setText("Video loaded. Preview is ready.");
                Toast.makeText(this, "Video added to MOVIX PRIME", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
